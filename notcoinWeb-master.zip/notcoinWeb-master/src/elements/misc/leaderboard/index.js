export { default as Leaderboard } from './Main.svelte';
