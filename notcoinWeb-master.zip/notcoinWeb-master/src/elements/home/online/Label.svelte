<script lang="js">
    export let index;
</script>

<span class="ml-[6px] text-[#ebebf599]">
    {['total players', 'online today', 'online'][index]}
</span>
