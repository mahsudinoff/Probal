<script lang="js">
    import Header from "../elements/Header.svelte";
    import Footer from "../elements/Footer.svelte";

    import { Home } from "../elements/home";
</script>

<!-- Home -->
    <Header />
    <Home />
    <Footer />
<!-- Home end -->
